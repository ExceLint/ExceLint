#!/usr/bin/bash

cp /cygdrive/z/dbarowy/Documents/FUSE/cc-binaries/12ad2a95-9adf-41c4-9848-aad9c3c36bea 12ad2a95-9adf-41c4-9848-aad9c3c36bea.xls
cp /cygdrive/z/dbarowy/Documents/FUSE/cc-binaries/0bc3776d-c8fe-4412-b679-e606045ef63a 0bc3776d-c8fe-4412-b679-e606045ef63a.xls
cp /cygdrive/z/dbarowy/Documents/FUSE/cc-binaries/083b06ba-f1f6-4508-b162-7ba76635a19f 083b06ba-f1f6-4508-b162-7ba76635a19f.xls
cp /cygdrive/z/dbarowy/Documents/FUSE/cc-binaries/00d918fa-4f64-453d-b01d-86dbd8cd0e99 00d918fa-4f64-453d-b01d-86dbd8cd0e99.xlsx
cp /cygdrive/z/dbarowy/Documents/FUSE/cc-binaries/0251fb69-a08b-4f12-8f4e-a8708bdba794 0251fb69-a08b-4f12-8f4e-a8708bdba794.xls
cp /cygdrive/z/dbarowy/Documents/FUSE/cc-binaries/01d1ed05-a970-49ac-b7c6-d8be29433a10 01d1ed05-a970-49ac-b7c6-d8be29433a10.xlsx
cp /cygdrive/z/dbarowy/Documents/FUSE/cc-binaries/018e374d-e6bb-4fd1-85f4-32b905a87621 018e374d-e6bb-4fd1-85f4-32b905a87621.xls
cp /cygdrive/z/dbarowy/Documents/FUSE/cc-binaries/014d9b7d-63a4-43d5-a00a-ad7d857bd8fb 014d9b7d-63a4-43d5-a00a-ad7d857bd8fb.xls
cp /cygdrive/z/dbarowy/Documents/FUSE/cc-binaries/01bc81c4-2261-4c9b-81de-5ea2e230282e 01bc81c4-2261-4c9b-81de-5ea2e230282e.xls
cp /cygdrive/z/dbarowy/Documents/FUSE/cc-binaries/0bdc0dbd-6172-4115-b711-6f9b2fd82e72 0bdc0dbd-6172-4115-b711-6f9b2fd82e72.xls
cp /cygdrive/z/dbarowy/Documents/FUSE/cc-binaries/089f32eb-30e5-4e6a-ae69-ed91acfb6457 089f32eb-30e5-4e6a-ae69-ed91acfb6457.xls
cp /cygdrive/z/dbarowy/Documents/FUSE/cc-binaries/03272b03-b5d3-43a6-9084-6034b505d537 03272b03-b5d3-43a6-9084-6034b505d537.xls
cp /cygdrive/z/dbarowy/Documents/FUSE/cc-binaries/095fc080-b127-4f2c-a607-0bd247d7c481 095fc080-b127-4f2c-a607-0bd247d7c481.xls
cp /cygdrive/z/dbarowy/Documents/FUSE/cc-binaries/06f4a180-b8eb-401c-88a7-c7bc04aa22c2 06f4a180-b8eb-401c-88a7-c7bc04aa22c2.xls
cp /cygdrive/z/dbarowy/Documents/FUSE/cc-binaries/08a0108b-0ae7-4a6a-aa4c-062cf866fc87 08a0108b-0ae7-4a6a-aa4c-062cf866fc87.xlsx
cp /cygdrive/z/dbarowy/Documents/FUSE/cc-binaries/00573192-d2bf-40d4-a920-3cb6032cf7f6 00573192-d2bf-40d4-a920-3cb6032cf7f6.xls
cp /cygdrive/z/dbarowy/Documents/FUSE/cc-binaries/00c886ae-971a-47e0-b8b2-8192478ba44c 00c886ae-971a-47e0-b8b2-8192478ba44c.xlsx
cp /cygdrive/z/dbarowy/Documents/FUSE/cc-binaries/04c5044e-be32-4206-a3f4-0955324ef5da 04c5044e-be32-4206-a3f4-0955324ef5da.xlsx
cp /cygdrive/z/dbarowy/Documents/FUSE/cc-binaries/00cbebaf-8142-47f1-a842-cc0dc0d52935 00cbebaf-8142-47f1-a842-cc0dc0d52935.xls
cp /cygdrive/z/dbarowy/Documents/FUSE/cc-binaries/0c4c53e1-a165-4d3b-88ed-921d59f5d94e 0c4c53e1-a165-4d3b-88ed-921d59f5d94e.xls
